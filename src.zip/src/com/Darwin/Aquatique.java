package com.Darwin;

public class Aquatique extends Animal {
    public Aquatique(String name , boolean isCarnivore) {
        super(name, Animal.AQUATIQUE, isCarnivore);
    }
}

