package com.Darwin;

public class Volant extends Animal {
    public Volant(String name, boolean isCarnivore) {
        super(name, Animal.VOLATILE, isCarnivore);
    }
}

