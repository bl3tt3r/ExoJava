package com.Darwin;

public class Terrestre extends Animal {
    public Terrestre(String name, boolean isCarnivore) {
        super(name, Animal.TERRESTRE, isCarnivore);
    }
}

