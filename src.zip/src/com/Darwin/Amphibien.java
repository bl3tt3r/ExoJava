package com.Darwin;

public class Amphibien extends Animal {
    public Amphibien(String name, boolean isCarnivore) {
        super(name, Animal.AMPHIBIEN, isCarnivore);
    }
}

