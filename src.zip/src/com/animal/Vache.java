package com.animal;

import com.Darwin.Terrestre;

public class Vache extends Terrestre {
    public Vache(String name) {
        super(name, false);
    }
}
