package com.animal;

import com.Darwin.Aquatique;

public class Poisson extends Aquatique {
    public Poisson(String name) {
        super(name, true);
    }
}
