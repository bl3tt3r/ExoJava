package com.animal;

import com.Darwin.Terrestre;

public class Tigre extends Terrestre {
    public Tigre(String name) {
        super(name, true);
    }
}
