package com.animal;

import com.Darwin.Terrestre;

public class Girafe extends Terrestre {
    public Girafe(String name) {
        super(name, false);
    }
}
