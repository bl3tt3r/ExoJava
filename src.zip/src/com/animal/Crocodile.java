package com.animal;

import com.Darwin.Amphibien;

public class Crocodile extends Amphibien {
    public Crocodile(String name) {
        super(name, true);
    }
}
