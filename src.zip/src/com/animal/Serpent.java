package com.animal;

import com.Darwin.Terrestre;

public class Serpent extends Terrestre {
    public Serpent(String name) {
        super(name, true);
    }
}
